import React from 'react';
import Navbar from './navbar/index';
import '../node_modules/bootstrap/dist/css/bootstrap.css';

function App() {
  return (
    <React.Fragment>
      <div className="container">
        <Navbar/>
       
      </div>
    </React.Fragment>
  );
}

export default App;
