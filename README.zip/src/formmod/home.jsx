import React from 'react';

const Home = () => {
    return ( 
        <div className="container">
            <div className="row">
                <div className="col-12">
                    <h1>Home Component</h1>
                </div>
            </div>
        </div>
     );
}
 
export default Home;