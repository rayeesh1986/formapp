import React from 'react';

const Notfound = () => {
    return ( 
        <div className="container">
            <div className="row">
                <div className="col-12">
                    <h1>Not Found Component</h1>
                </div>
            </div>
        </div>
     );
}
 
export default Notfound;