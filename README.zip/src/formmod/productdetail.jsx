import React from 'react';

const Productdetail = () => {
    return ( 
        <div className="container">
            <div className="row">
                <div className="col-12">
                    <h1>Product Detail Component</h1>
                </div>
            </div>
        </div>
     );
}
 
export default Productdetail;