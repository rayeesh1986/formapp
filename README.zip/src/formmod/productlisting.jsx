import React from 'react';

const Productlisting = () => {
    return ( 
        <div className="container">
            <div className="row">
                <div className="col-12">
                    <h1>Product Listing Component</h1>
                </div>
            </div>
        </div>
     );
}
 
export default Productlisting;