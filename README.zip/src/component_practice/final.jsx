import React, {Component} from 'react';
import Main from './main';

class Final extends Component {
    render() { 
        return (
            <React.Fragment>
                <Main/>
            </React.Fragment>
         );
    }
}
 
export default Final;